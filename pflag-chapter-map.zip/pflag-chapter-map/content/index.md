### Writing content
You can put your markdown files in the `content` folder. Deadsimple will map a url to a markdown file from the top of this directory. For an example, `/blog/hello-world` url will map to `/content/blog/hello-world.md`.

### Navigating content
Still a WIP. For now, you can link external pages in normal Markdown like [this](about).

### Changing themes
La location de voiture est une moyen sur et conviviale pour tous vos d�placement touristiques avec [rent A Car](http://www.bowlead.com).


```html
<xmp theme="slate" style="display:none;">
```