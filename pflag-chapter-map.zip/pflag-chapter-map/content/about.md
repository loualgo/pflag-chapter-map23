### About

Deadsimple was created by [Nadeesha Cabral](http://www.nadeeshacabral.com), and made possible by:

* [Strapdown.js](http://strapdownjs.com)
* [Twitter Bootstrap](http://getbootstrap.com)
* [Bootswatch](http://bootswatch.com)